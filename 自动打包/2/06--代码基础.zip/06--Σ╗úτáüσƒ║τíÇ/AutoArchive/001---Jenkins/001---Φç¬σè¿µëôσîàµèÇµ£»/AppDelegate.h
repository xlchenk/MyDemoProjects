//
//  AppDelegate.h
//  001---自动打包技术
//
//  Created by cooci on 2018/9/4.
//  Copyright © 2018年 cooci. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

