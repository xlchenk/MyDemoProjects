//
//  main.m
//  001---自动打包技术
//
//  Created by cooci on 2018/9/4.
//  Copyright © 2018年 cooci. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
